import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

IconData _resolveIcon(dynamic icon, IconData fallback) {
  if (icon == null) return fallback;
  if (icon is IconData) return icon;
  if (icon is String) {
    final map = <String, IconData>{
      'rocket': FontAwesomeIcons.rocket, 'skull': FontAwesomeIcons.skull,
      'crown': FontAwesomeIcons.crown, 'dragon': FontAwesomeIcons.dragon,
      'mask': FontAwesomeIcons.mask, 'user': FontAwesomeIcons.user,
      'heart': FontAwesomeIcons.heart, 'star': FontAwesomeIcons.star,
      'fire': FontAwesomeIcons.fire, 'bolt': FontAwesomeIcons.bolt,
      'shield': FontAwesomeIcons.shield, 'ghost': FontAwesomeIcons.ghost,
      'hatwizard': FontAwesomeIcons.hatWizard, 'bell': FontAwesomeIcons.bell,
      'comment': FontAwesomeIcons.comment, 'envelope': FontAwesomeIcons.envelope,
      'paper-plane': FontAwesomeIcons.paperPlane,
      'circle-info': FontAwesomeIcons.circleInfo, 'info': FontAwesomeIcons.circleInfo,
      'check': FontAwesomeIcons.check, 'times': FontAwesomeIcons.xmark,
      'xmark': FontAwesomeIcons.xmark, 'play': FontAwesomeIcons.play,
      'pause': FontAwesomeIcons.pause, 'stop': FontAwesomeIcons.stop,
    };
    return map[icon.toLowerCase()] ?? fallback;
  }
  if (icon is Map && icon['icon'] != null) return _resolveIcon(icon['icon'], fallback);
  return fallback;
}

Widget iconFrom(dynamic icon, {Color? color, double? size, IconData fallback = Icons.help_outline}) =>
    Icon(_resolveIcon(icon, fallback), color: color, size: size);

IconData iconDataFrom(dynamic icon, {IconData fallback = Icons.help_outline}) =>
    _resolveIcon(icon, fallback);
