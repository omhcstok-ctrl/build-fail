// landing_page.dart
// Splash screen dengan animasi logo "YZ" dan branding text.
// Durasi total: 5 detik, lalu otomatis ke halaman login.
//
// Timeline:
//   Detik 0.0 - 0.3  : Fade in background gradient
//   Detik 0.0 - 2.0  : Animasi logo "YZ" (scale + rotate + glow)
//   Detik 2.0 - 3.0  : Animasi text "YakuzaXsilence" (slide up + fade)
//   Detik 3.0 - 5.0  : Animasi text "Developer OmhcSilence" (slide up + fade)
//   Detik 5.0        : Navigate ke LoginPage

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'login_page.dart';

// ── COLOR SCHEME ─────────────────────────────────────────────────────────────
class _LC {
  static const bg       = Color(0xFF000000);
  static const bg2      = Color(0xFF0a0a0a);
  static const accent   = Color(0xFFFF3B30);
  static const accent2  = Color(0xFFFF6B6B);
  static const accent3  = Color(0xFFCC2E25);
  static const text     = Color(0xFFE0E7FF);
  static const textDim  = Color(0x73E0E7FF);
  static const textDim2 = Color(0x38E0E7FF);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  // ── Animation Controllers ────────────────────────────────────────────────
  late AnimationController _bgController;      // Background fade + glow
  late AnimationController _logoController;    // Logo "YZ" reveal
  late AnimationController _brandController;   // Text "YakuzaXsilence"
  late AnimationController _devController;     // Text "Developer OmhcSilence"
  late AnimationController _exitController;    // Fade out seluruh halaman
  late AnimationController _ringController;    // Rotating ring di sekitar logo

  // ── Animations ───────────────────────────────────────────────────────────
  late Animation<double> _bgFade;
  late Animation<double> _logoScale;
  late Animation<double> _logoFade;
  late Animation<double> _logoGlow;
  late Animation<double> _brandSlide;
  late Animation<double> _brandFade;
  late Animation<double> _devSlide;
  late Animation<double> _devFade;
  late Animation<double> _exitFade;

  bool _navigating = false;

  @override
  void initState() {
    super.initState();

    // Set full-screen immersive saat splash
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    // ── 1. Background: fade in dari 0 → 1 dalam 800ms ──
    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _bgFade = CurvedAnimation(parent: _bgController, curve: Curves.easeOut);

    // ── 2. Logo "YZ": scale + fade + glow (0 → 2000ms) ──
    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    _logoScale = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.elasticOut),
    );
    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );
    _logoGlow = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoController,
        curve: const Interval(0.4, 1.0, curve: Curves.easeOut),
      ),
    );

    // ── 3. Rotating ring di sekitar logo (loop) ──
    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    // ── 4. Text "YakuzaXsilence" (2000ms → 3000ms) ──
    _brandController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _brandSlide = Tween<double>(begin: 30.0, end: 0.0).animate(
      CurvedAnimation(parent: _brandController, curve: Curves.easeOutCubic),
    );
    _brandFade = CurvedAnimation(parent: _brandController, curve: Curves.easeOut);

    // ── 5. Text "Developer OmhcSilence" (3000ms → 5000ms) ──
    _devController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _devSlide = Tween<double>(begin: 20.0, end: 0.0).animate(
      CurvedAnimation(parent: _devController, curve: Curves.easeOutCubic),
    );
    _devFade = CurvedAnimation(parent: _devController, curve: Curves.easeOut);

    // ── 6. Exit fade (delay di akhir) ──
    _exitController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _exitFade = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _exitController, curve: Curves.easeInOut),
    );

    // ── START THE SEQUENCE ────────────────────────────────────────────────
    _startSequence();
  }

  Future<void> _startSequence() async {
    // t = 0ms: background fade in + logo mulai
    _bgController.forward();
    _logoController.forward();

    // t = 1800ms: logo udah selesai, mulai text brand
    await Future.delayed(const Duration(milliseconds: 1800));
    if (!mounted) return;
    _brandController.forward();

    // t = 3000ms: mulai text developer
    await Future.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    _devController.forward();

    // t = 4600ms: mulai exit fade
    await Future.delayed(const Duration(milliseconds: 1600));
    if (!mounted) return;
    _exitController.forward();

    // t = 5000ms: navigate ke login
    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted) return;
    _goToLogin();
  }

  void _goToLogin() {
    if (_navigating) return;
    _navigating = true;

    // Restore system UI sebelum pindah halaman
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    if (mounted) {
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 500),
          pageBuilder: (context, animation, secondaryAnimation) =>
              LoginPage(),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            // Smooth fade transition ke login
            return FadeTransition(
              opacity: CurvedAnimation(
                parent: animation,
                curve: Curves.easeInOut,
              ),
              child: child,
            );
          },
        ),
      );
    }
  }

  @override
  void dispose() {
    _bgController.dispose();
    _logoController.dispose();
    _brandController.dispose();
    _devController.dispose();
    _exitController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final logoSize = size.width * 0.35; // 35% dari lebar layar

    return Scaffold(
      backgroundColor: Colors.black,
      body: FadeTransition(
        opacity: _exitFade,
        child: Stack(
          children: [
            // ── BACKGROUND: radial gradient + subtle animated glow ──
            AnimatedBuilder(
              animation: _bgController,
              builder: (context, child) {
                return Opacity(
                  opacity: _bgFade.value,
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.center,
                        radius: 1.2,
                        colors: [
                          Color(0xFF1a0a0a), // subtle red tint di tengah
                          Color(0xFF0a0a0a),
                          Color(0xFF000000),
                        ],
                        stops: [0.0, 0.4, 1.0],
                      ),
                    ),
                  ),
                );
              },
            ),

            // ── Subtle animated ambient glow di belakang logo ──
            AnimatedBuilder(
              animation: _ringController,
              builder: (context, child) {
                final t = _ringController.value * 2 * math.pi;
                final opacity = 0.04 + (math.sin(t) * 0.02);
                return Positioned.fill(
                  child: Center(
                    child: Container(
                      width: logoSize * 2.2,
                      height: logoSize * 2.2,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            _LC.accent.withOpacity(opacity.clamp(0.0, 1.0)),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),

            // ── CONTENT ──
            SafeArea(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Spacer(flex: 3),

                    // ══════════════════════════════════════════════════════
                    // LOGO "YZ" — Muncul detik 0-2
                    // ══════════════════════════════════════════════════════
                    AnimatedBuilder(
                      animation: _logoController,
                      builder: (context, child) {
                        return Transform.scale(
                          scale: _logoScale.value,
                          child: Opacity(
                            opacity: _logoFade.value,
                            child: _buildLogo(logoSize),
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 40),

                    // ══════════════════════════════════════════════════════
                    // TEXT "YakuzaXsilence" — Muncul detik 2-3
                    // ══════════════════════════════════════════════════════
                    AnimatedBuilder(
                      animation: _brandController,
                      builder: (context, child) {
                        return Transform.translate(
                          offset: Offset(0, _brandSlide.value),
                          child: Opacity(
                            opacity: _brandFade.value,
                            child: child,
                          ),
                        );
                      },
                      child: ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [_LC.accent, _LC.accent2, _LC.accent3],
                        ).createShader(bounds),
                        blendMode: BlendMode.srcIn,
                        child: const Text(
                          'YakuzaXsilence',
                          style: TextStyle(
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 28,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 6,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Thin accent line
                    AnimatedBuilder(
                      animation: _brandController,
                      builder: (context, child) {
                        return Opacity(
                          opacity: _brandFade.value,
                          child: Container(
                            width: 60 * _brandFade.value,
                            height: 2,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [_LC.accent, _LC.accent3],
                              ),
                              borderRadius: BorderRadius.circular(1),
                              boxShadow: [
                                BoxShadow(
                                  color: _LC.accent.withOpacity(0.6),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 24),

                    // ══════════════════════════════════════════════════════
                    // TEXT "Developer OmhcSilence" — Muncul detik 3-5
                    // ══════════════════════════════════════════════════════
                    AnimatedBuilder(
                      animation: _devController,
                      builder: (context, child) {
                        return Transform.translate(
                          offset: Offset(0, _devSlide.value),
                          child: Opacity(
                            opacity: _devFade.value,
                            child: child,
                          ),
                        );
                      },
                      child: const Text(
                        'Developer OmhcSilence',
                        style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 12,
                          letterSpacing: 4,
                          color: _LC.textDim,
                        ),
                      ),
                    ),

                    const Spacer(flex: 4),

                    // ── Footer loading indicator (subtle) ──
                    AnimatedBuilder(
                      animation: _logoController,
                      builder: (context, child) {
                        return Opacity(
                          opacity: _logoFade.value * 0.5,
                          child: const Padding(
                            padding: EdgeInsets.only(bottom: 40),
                            child: SizedBox.shrink(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // LOGO "YZ" dengan:
  //   - Rounded square gradient background
  //   - Rotating dashed ring
  //   - Big "YZ" text di tengah
  //   - Animated glow
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildLogo(double size) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // ── Rotating dashed ring ──
          AnimatedBuilder(
            animation: _ringController,
            builder: (context, child) {
              return Transform.rotate(
                angle: _ringController.value * 2 * math.pi,
                child: CustomPaint(
                  size: Size(size * 1.35, size * 1.35),
                  painter: _DashedRingPainter(
                    color: _LC.accent.withOpacity(0.4),
                    dashCount: 24,
                    ringRadius: size * 0.65,
                    strokeWidth: 1.5,
                  ),
                ),
              );
            },
          ),

          // ── Outer glow ──
          AnimatedBuilder(
            animation: _logoGlow,
            builder: (context, child) {
              return Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(size * 0.28),
                  boxShadow: [
                    BoxShadow(
                      color: _LC.accent.withOpacity(0.5 * _logoGlow.value),
                      blurRadius: 40 * _logoGlow.value,
                      spreadRadius: 4 * _logoGlow.value,
                    ),
                    BoxShadow(
                      color: _LC.accent2.withOpacity(0.3 * _logoGlow.value),
                      blurRadius: 60 * _logoGlow.value,
                      spreadRadius: 2 * _logoGlow.value,
                    ),
                  ],
                ),
              );
            },
          ),

          // ── Main logo box ──
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(size * 0.28),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [_LC.accent, _LC.accent3],
              ),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1.5,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Subtle shine effect di pojok kiri atas
                Positioned(
                  top: 0,
                  left: 0,
                  child: Container(
                    width: size * 0.5,
                    height: size * 0.5,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(size * 0.28),
                        bottomRight: Radius.circular(size * 0.5),
                      ),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.white.withOpacity(0.25),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),

                // "YZ" Text
                ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.white, Color(0xFFFFE0E0)],
                  ).createShader(bounds),
                  child: Text(
                    'YZ',
                    style: TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: size * 0.42,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Loading dots (animasi subtle di footer) ──
  Widget _buildDot(int index) {
    return AnimatedBuilder(
      animation: _ringController,
      builder: (context, child) {
        final phase = (_ringController.value + index * 0.15) % 1.0;
        final scale = 0.5 + 0.5 * math.sin(phase * 2 * math.pi).abs();
        final opacity = 0.3 + 0.7 * scale;
        return Container(
          width: 6,
          height: 6,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _LC.accent.withOpacity(opacity.clamp(0.0, 1.0)),
            boxShadow: [
              BoxShadow(
                color: _LC.accent.withOpacity(0.4 * scale),
                blurRadius: 6,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// DASHED RING PAINTER — untuk rotating ring di sekitar logo
// ══════════════════════════════════════════════════════════════════════════════
class _DashedRingPainter extends CustomPainter {
  final Color color;
  final int dashCount;
  final double ringRadius;
  final double strokeWidth;

  _DashedRingPainter({
    required this.color,
    required this.dashCount,
    required this.ringRadius,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final angleStep = (2 * math.pi) / dashCount;
    final dashLength = angleStep * 0.45; // 45% dash, 55% gap

    for (int i = 0; i < dashCount; i++) {
      final startAngle = i * angleStep;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: ringRadius),
        startAngle,
        dashLength,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_DashedRingPainter oldDelegate) {
    return oldDelegate.color != color ||
        oldDelegate.ringRadius != ringRadius ||
        oldDelegate.dashCount != dashCount;
  }
}